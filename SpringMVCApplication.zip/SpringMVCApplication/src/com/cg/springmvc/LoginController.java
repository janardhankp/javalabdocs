package com.cg.springmvc;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LoginController
{

	@RequestMapping("/showLogin")
	public String showLoginPage(Model model)
	{
		User user=new User();
		model.addAttribute("Login", user);
		return "Login";
		
	}
	/*@RequestMapping("/validateUser")
	public String validateUserLogin(@RequestParam("txtUId") String username,@RequestParam("txtPass")String password)
	{
		
		if(username.equals("kamal")&&password.equals("kamal"))
				{
			return"success";
			
				}
		else
		return "error";
		
	}*/

@RequestMapping("/validateUser")
public String validateUserLogin(@ModelAttribute User userBean)
{
	String username=userBean.getUsername();
	String password=userBean.getPassword();
	if(username.equals("kamal")&&password.equals("kamal"))
	{
return"success";

	}
else
return "error";
	
	
	
}
}

