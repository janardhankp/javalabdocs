package com.cg.springmvc;

import java.time.LocalDateTime;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;


public class SimpleController implements Controller{

	@Override
	public ModelAndView handleRequest(HttpServletRequest arg0,
			HttpServletResponse arg1) throws Exception {
		LocalDateTime dt=LocalDateTime.now();
		String todayDate=dt.toString();
		ModelAndView model=new ModelAndView("Hello",
			"Today",todayDate);
		return model;
		
	}


}