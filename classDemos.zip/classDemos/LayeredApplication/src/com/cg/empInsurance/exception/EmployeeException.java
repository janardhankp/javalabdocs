package com.cg.empInsurance.exception;

public class EmployeeException extends Exception{
	String errorMessage;
	public EmployeeException(String msg){
		errorMessage=msg;
	}
	
	public String getMessage(){
		return errorMessage;
	}
}
