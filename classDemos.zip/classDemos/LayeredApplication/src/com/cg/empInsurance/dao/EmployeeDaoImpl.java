package com.cg.empInsurance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.empInsurance.dto.Employee;
import com.cg.empInsurance.exception.EmployeeException;

public class EmployeeDaoImpl implements EmployeeDao{
	
	Connection conn;

	@Override
	public void insertEmployeeDetails(Employee emp) throws EmployeeException {
		
		conn=DBUtil.getConnection();
		
		String sql="insert into employee_details values"+"(?,?,?,?,?)";
		
		try {
			PreparedStatement pstmt=conn.prepareStatement(sql);
			
			pstmt.setInt(1, emp.getEmployeeId());
			pstmt.setString(2, emp.getEmployeeName());
			pstmt.setDouble(3, emp.getSalary());
			pstmt.setString(4, emp.getDesignation());
			pstmt.setString(5, emp.getInsuranceScheme());
			int r=pstmt.executeUpdate();
			if(r==1){
				System.out.println("employee record inserted..");
			}
		} catch (SQLException e) {
			
			throw new EmployeeException(e.getMessage());
		}
	
	}

	@Override
	public ArrayList<Employee> getEmployeeList(String scheme) throws EmployeeException {
		
		conn=DBUtil.getConnection();
		ArrayList<Employee> list=new ArrayList<Employee>();
		
		
		String sql="select employee_Id,empName,salary, designation,insuranceScheme from employee_details where insuranceScheme=?";
		
		try {
			PreparedStatement pstmt=conn.prepareStatement(sql);
			
			pstmt.setString(1, scheme);
			ResultSet rs=pstmt.executeQuery();
			
			while(rs.next()){
				Employee emp=new Employee();
				//int id=rs.getInt(1);
				//emp.setEmployeeId(id);
				 emp.setEmployeeId(rs.getInt("employee_id"));// we can write this inplace of above two..........
				
				emp.setEmployeeName(rs.getString(2));
				emp.setSalary(rs.getDouble(3));
				emp.setDesignation(rs.getString(4));
				emp.setInsuranceScheme(rs.getString(5));
				
				list.add(emp);
				
				
			}
		return list;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new EmployeeException(e.getMessage());
		}
		
	
	}

	@Override
	public Employee getEmployeeDetails(int empid) throws EmployeeException {
		// TODO Auto-generated method stub
		conn=DBUtil.getConnection();
		return null;
	}

}
