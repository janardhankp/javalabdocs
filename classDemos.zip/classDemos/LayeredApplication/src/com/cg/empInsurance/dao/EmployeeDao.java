package com.cg.empInsurance.dao;

import java.util.ArrayList;

import com.cg.empInsurance.dto.Employee;
import com.cg.empInsurance.exception.EmployeeException;

public interface EmployeeDao {

	public void insertEmployeeDetails(Employee emp)
	throws EmployeeException;
	//public getEmployeeList(String scheme);
	public ArrayList<Employee> getEmployeeList(String scheme)throws EmployeeException;
	public Employee getEmployeeDetails(int empid)throws EmployeeException;
	//Employee getEmployeeDetails();
	
}
