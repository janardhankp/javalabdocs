package com.cg.empInsurance.pl;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.empInsurance.dto.Employee;
import com.cg.empInsurance.exception.EmployeeException;
import com.cg.empInsurance.service.EmployeeService;
import com.cg.empInsurance.service.EmployeeServiceImpl;

//package com.cg.empInsurance.pl;

import java.sql.Connection;

import com.cg.empInsurance.dao.DBUtil;
import com.cg.empInsurance.exception.EmployeeException;

public class Client {
	public static void main(String[] args) {
		
		Connection conn = null;
		
			try {
				conn = DBUtil.getConnection();
				if(conn!=null)
			System.out.println("db connected");
		else
			System.out.println("Error in DB connection");
			} catch (EmployeeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


		EmployeeService service=new EmployeeServiceImpl();
		Scanner sc= new Scanner(System.in);
		String empid, empName,salary,desig;
		System.out.println("1.Add employee details");
		System.out.println("2.get employee list based on insurance scheme");
		System.out.println("3.exit");
		System.out.println("enter your choice");
		String choice=sc.next();
		switch (choice) {
		case "1":
			Employee emp=new Employee();
			System.out.println("enter Employee Id");
			
			do{
				empid=sc.next();
				
				boolean result=service.validateEmployeeId(empid);
				if(result==true){
					
					emp.setEmployeeId(Integer.parseInt(empid));
					break;
				}else
					System.out.println("invalid emp id! enter valid id");
				}while(true);
		
					
					System.out.println("enter Employee name");
				
				do{
					empName=sc.next();
					boolean result=service.validateEmpName(empName);
					if(result==true){
						
						emp.setEmployeeName(empName);
						break;
					}
					else
						System.out.println("name invalid ! enter valid name");
					}while(true);
				
				
				
				
				
					System.out.println("enter salary");
				
				do{
					salary=sc.next();
					boolean result=service.validateSalary(salary);
					if(result==true){
						
						emp.setSalary(Double.parseDouble(salary));
						break;
					}
					else
						System.out.println("invalid salary enter valid salary range");
					}while(true);
				
					System.out.println("enter designation");
				
				do{
					desig=sc.next();
					boolean result=service.validateDesignation(desig);
					if(result==true){
						
						emp.setDesignation(desig);
						break;
					}else
						System.out.println("invalid designation enter valid designation");
					}while(true);
				
				
			try {
				String scheme=service.findInsuranceScheme(emp);
				emp.setInsuranceScheme(scheme);
				service.insertEmployeeDetails(emp);
			} catch (EmployeeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
									
			break;
	
			
		case "2":
			String scheme;
			System.out.println("enter insurance scheme");
			scheme=sc.next();
			scheme="Scheme "+ scheme;
			try{
				ArrayList<Employee> list= service.getEmployeeList(scheme);
				if(list.size()==0)
					System.out.println("No employee in this scheme");
				else{
					for(Employee e:list){
						System.out.println(e);
					}
				}
			}catch(EmployeeException e){
				System.out.println(e.getMessage());
			}
			break;
		case"3":

		default:
			break;
		}
		sc.close();
	}
}
