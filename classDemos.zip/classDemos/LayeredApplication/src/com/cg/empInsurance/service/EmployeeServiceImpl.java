package com.cg.empInsurance.service;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.empInsurance.dao.EmployeeDao;
import com.cg.empInsurance.dao.EmployeeDaoImpl;
import com.cg.empInsurance.dto.Employee;
import com.cg.empInsurance.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService{
	
	
	EmployeeDao dao=new EmployeeDaoImpl();

		
		@Override
		public void insertEmployeeDetails(Employee emp) throws EmployeeException {
			// TODO Auto-generated method stub
			dao.insertEmployeeDetails(emp);
		}
		
		@Override
		public ArrayList<Employee> getEmployeeList(String scheme)throws EmployeeException {
			ArrayList<Employee> list=dao.getEmployeeList(scheme);
			return list;
		}
		
		@Override
		public Employee getEmployeeDetails(int empid) throws EmployeeException {
			// TODO Auto-generated method stub
			Employee emp=dao.getEmployeeDetails(empid);
			return emp;
		}
	
	
	@Override
	public String findInsuranceScheme(Employee emp) {

		double sal=emp.getSalary();
		//String name=emp.getEmployeeName();
		String empdesig=emp.getDesignation();
		//int empid=emp.getEmployeeId();
		//String scheme=emp.getInsuranceScheme();
		
		if((sal>5000 && sal<20000)&&	empdesig.equals("system associate")){
			return"Scheme C";
			
		}else if((sal>=20000&&sal<40000)&&empdesig.equals("programmer")){
			return "Scheme B";
			
			
		}else if((sal>=40000)&&empdesig.equals("manager")){
			return "Scheme A";
			
			
		}else if((sal<5000)&&empdesig.equals("clerk")){
			return "No Scheme";
		}
		return "N/A";
	}

	@Override
	public boolean validateEmployeeId(String empid) {
		Pattern pattern=Pattern.compile("^[0-9]{6}$");
		Matcher matcher=pattern.matcher(empid);
		if(matcher.find())
			return true;
		else
			return false;
	}

	@Override
	public boolean validateEmpName(String empName) {
		Pattern pattern=Pattern.compile("^[A-Z][a-z]{5,30}$");
		Matcher matcher=pattern.matcher(empName);
		if(matcher.find())
			return true;
		else
			return false;
	}

	@Override
	public boolean validateSalary(String salary) {
		
		
		Pattern pattern=Pattern.compile("^[0-9]{4,}$");
		Matcher matcher=pattern.matcher(salary);
		if(matcher.find())
			return true;
		else
			return false;
		
	}

	@Override
	public boolean validateDesignation(String design) {
		Pattern pattern=Pattern.compile("^[a-z]{5,50}$");
		Matcher matcher=pattern.matcher(design);
		if(matcher.find())
			return true;
		else
			return false;
	
	}
	
}
