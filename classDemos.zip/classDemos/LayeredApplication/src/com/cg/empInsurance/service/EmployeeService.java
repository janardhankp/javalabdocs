package com.cg.empInsurance.service;

import java.util.ArrayList;

import com.cg.empInsurance.dto.Employee;
import com.cg.empInsurance.exception.EmployeeException;

public interface EmployeeService {

	public void insertEmployeeDetails(Employee emp)throws EmployeeException;
			
	public ArrayList<Employee> getEmployeeList(String scheme)throws EmployeeException;
	public Employee getEmployeeDetails(int empid)throws EmployeeException;
	
	
	public String findInsuranceScheme(Employee emp);
	public boolean validateEmployeeId(String empid);
	public boolean validateEmpName(String empName);
	public boolean validateSalary(String salary);
	public boolean validateDesignation(String design);
	
	
}
