import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
//import java.sql.Statement;
import java.util.Scanner;


public class PreparedStmtMine {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection conn;
		PreparedStatement pstmt;
		String employeeId,empName,salary,design,insuranceScheme;
		Scanner sc= new Scanner(System.in);
		System.out.println("enter employeeId");
		employeeId=sc.next();
		int empid=Integer.parseInt(employeeId);
		System.out.println("enter employee name");
		empName=sc.next();
		
		System.out.println("enter salary");
		salary=sc.next();
		double empSalary=Double.parseDouble(salary);
		
		System.out.println("enter employee designation");
		design=sc.next();
		System.out.println("enter insurance scheme");
		insuranceScheme=sc.next();
				sc.close();
		
		
			try {
				conn=DriverManager.getConnection("jdbc:oracle:thin:@ndaoracle.igatecorp.com:1521:orcl11g","lab011trg19","lab011oracle");
				System.out.println("db connected");
				String query="insert into employee_details values"+"(?,?,?,?,?)";
				pstmt= conn.prepareStatement(query);
				pstmt.setInt(1,empid);
				pstmt.setString(2,empName);
				pstmt.setDouble(3,empSalary);
				pstmt.setString(4,design);
				pstmt.setString(5,insuranceScheme);
				int rows=pstmt.executeUpdate();
				System.out.println(rows+" inserted..");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}

	

}
