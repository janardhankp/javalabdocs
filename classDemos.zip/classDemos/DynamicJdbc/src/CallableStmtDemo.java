import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;



public class CallableStmtDemo {

	public static void main(String[] args) {
		Connection conn;
		
		try {
			conn=DriverManager.getConnection("jdbc:oracle:thin:@ndaoracle.igatecorp.com:1521:orcl11g","lab011trg19","lab011oracle");
			System.out.println("db connected");
			conn.setAutoCommit(false);
			String sql="{call getBookName(?,?) }";
			CallableStatement cstmt=conn.prepareCall(sql);
			cstmt.setInt(1, 10000004);
			cstmt.registerOutParameter(2, java.sql.Types.VARCHAR);
			cstmt.execute();
			String bookName=cstmt.getString(2);
			System.out.println("book Name: "+bookName);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
