package com.cg.enquiry.exception;

public class EnquiryException extends Throwable {
   String errorMessage;
	
	

	public EnquiryException(String msg)
	{
		
		
		errorMessage=msg;
		
		
	}
	public String getMesage()
	{
		return errorMessage;
	}

}

