package com.cg.enquiry.test;

import junit.framework.Assert;

import org.junit.Test;

import com.cg.enquiry.dao.EnquiryDao;
import com.cg.enquiry.dao.EnquiryDaoImpl;
import com.cg.enquiry.dto.Enquiry;
import com.cg.enquiry.exception.EnquiryException;

public class EnquiryDaoTest {
	
	@Test
	public void testInsertFunction(){
		Enquiry enquiry= new Enquiry();
		enquiry.setFirstName("Janardhan");
		enquiry.setLastName("Reddy");
		enquiry.setCity("Bangalore");
		enquiry.setContactNum(8790244391L);
		enquiry.setDomain("Jee");
		EnquiryDao dao=new EnquiryDaoImpl();
		
		try {
			int id=dao.insertEnquiryDetails(enquiry);
			Assert.assertEquals(1001, id);
		} catch (EnquiryException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMesage());
		}
		
		
	}

}
