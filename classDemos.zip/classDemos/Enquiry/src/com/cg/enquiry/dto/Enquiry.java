package com.cg.enquiry.dto;

public class Enquiry {
	
	private int enquiryId ;
	private  String firstName;
	private String lastName;
	private long contactNum;
	private String domain;
	private String city;
	
	
	public int getEnquiryId() {
		return enquiryId;
	}
	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public long getContactNum() {
		return contactNum;
	}
	public void setContactNum(long l) {
		this.contactNum = l;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return enquiryId+"	"+firstName+"	"+lastName+"	"+contactNum+"	"+domain+"	"+city;
	}
	
	
	

}
