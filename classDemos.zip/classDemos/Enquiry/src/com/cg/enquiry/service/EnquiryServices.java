package com.cg.enquiry.service;

import java.util.ArrayList;

import com.cg.enquiry.dto.Enquiry;
import com.cg.enquiry.exception.EnquiryException;

public interface EnquiryServices {
	
	
	public int insertEnquiryDetails(Enquiry enq) throws EnquiryException;

	public Enquiry getEnquiryList(int enqId) throws EnquiryException;

	
	
	
	public boolean validateEnquryId(String enquiryId);
    public boolean validatefirstName(String firstName);
	public boolean validatelastName(String lastName);
	public boolean validatecontactNum(String contactNum);
	public boolean validatedomain(String domain);
	
	
}
