package com.cg.enquiry.service;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.enquiry.dto.Enquiry;
import com.cg.enquiry.dao.EnquiryDao;
import com.cg.enquiry.dao.EnquiryDaoImpl;
import com.cg.enquiry.dto.Enquiry;
import com.cg.enquiry.exception.EnquiryException;

public class EnquiryServicesImpl implements EnquiryServices{

	
	EnquiryDao dao=new EnquiryDaoImpl();

	@Override
	public int insertEnquiryDetails(Enquiry enq) throws EnquiryException {
		
		return dao.insertEnquiryDetails(enq);
		
	}

	@Override
	public Enquiry getEnquiryList(int enqId) throws EnquiryException {
	
		Enquiry enq=dao.getEnquiryDetails(enqId);
		
		return enq;
	}

	@Override
	public boolean validateEnquryId(String enquiryId) {
		Pattern pattern=Pattern.compile("^[0-9]{6}$");
		Matcher matcher=pattern.matcher(enquiryId);
		if(matcher.find())
		return true;	
		else
		return false;
	}

	@Override
	public boolean validatefirstName(String firstName) {
		Pattern pattern=Pattern.compile("^[A-Z][a-z]{5,}$");
		Matcher matcher=pattern.matcher(firstName);
		if(matcher.find())
		return true;
		else
		
		return false;
	}

	@Override
	public boolean validatelastName(String lastName) {
		Pattern pattern=Pattern.compile("^[A-Z][a-z]{3,}$");
		Matcher matcher=pattern.matcher(lastName);
		if(matcher.find())
		return true;
		else
		return false;
	}

	@Override
	public boolean validatecontactNum(String contactNum) {
		Pattern pattern=Pattern.compile("[0-9]{10}");
		Matcher matcher=pattern.matcher(contactNum);
		if(matcher.find())
		return true;
		else
		return false;
	}

	@Override
	public boolean validatedomain(String domain) {
		Pattern pattern=Pattern.compile("^[A-Z][a-z]{2,}$");
		Matcher matcher=pattern.matcher(domain);
		if(matcher.find())
		return true;
		else
		return false;
	}

	
	
}
