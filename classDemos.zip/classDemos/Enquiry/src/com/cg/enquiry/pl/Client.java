package com.cg.enquiry.pl;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.Scanner;


import com.cg.enquiry.dao.DBUtil;
import com.cg.enquiry.dto.Enquiry;
import com.cg.enquiry.exception.EnquiryException;
import com.cg.enquiry.dto.Enquiry;
import com.cg.enquiry.exception.EnquiryException;
import com.cg.enquiry.service.EnquiryServices;
import com.cg.enquiry.service.EnquiryServicesImpl;

public class Client {
	
	public static void main(String[] args) throws EnquiryException {
		
		Connection conn = DBUtil.getConnection();
		if(conn!=null)
			System.out.println("DB connected");
		else
			System.out.println("not connected");
		
		
		EnquiryServices service=new EnquiryServicesImpl();
		
		Enquiry enq=new Enquiry();
		
		Scanner sc=new Scanner(System.in);
		String  enquiryId,firstName,lastName,contactNum,domain,city;
		do{
			
			System.out.println("1.Add Enquiry Details");
			System.out.println("2.Get Enquiry Details based on city");
			System.out.println("3.exit");
			System.out.println("Enter your choice");
			String choice=sc.next();
			
			switch(choice){
			
			case "1":
			
				System.out.println("Enter FirstName: ");
				
				do{
					firstName=sc.next();
				boolean result=service.validatefirstName(firstName);
				if(result==true){
					enq.setFirstName(firstName);
					break;
				}
				else
					System.out.println("Invalid FirstName !.enter valid Id");
				}while(true);
				
				 System.out.println("Enter LastName: ");
					
					do{
						lastName=sc.next();
					boolean result=service.validatelastName(lastName);
					if(result==true){
						enq.setLastName(lastName);
						break;
					}
					else
						System.out.println("Invalid LastName !.enter valid Id");
					}while(true);
					
					 System.out.println("Enter ContactNumber: ");
						
						do{
							contactNum=sc.next();
						boolean result=service.validatecontactNum(contactNum);
						if(result==true){
							enq.setContactNum(Long.parseLong(contactNum));
							break;
						}
						else
							System.out.println("Invalid ContactNumber !.enter valid Id");
						}while(true);
						
						 System.out.println("Enter Domain: ");
							
							do{
								domain=sc.next();
							boolean result=service.validatedomain(domain);
							if(result==true){
								enq.setDomain(domain);
								break;
							}
							else
								System.out.println("Invalid Domain!.enter valid Id");
							}while(true);
						
							
							
							
							
							System.out.println("Enter city: ");
							
							do{
								city=sc.next();
							boolean result=service.validatefirstName(city);
							if(result==true){
								enq.setCity(city);
								break;
							}
							else
								System.out.println("Invalid FirstName !.enter valid Id");
							}while(true);
						try
				 			{
				 				//String city=service.findInsuranceScheme(emp);
				 				
				 				//enq.setInsuranceScheme(scheme);
				 				int id=service.insertEnquiryDetails(enq);
				 				System.out.println("Your enquiry id : "+ id);
				 			}
				 			catch(EnquiryException e){
				 				e.printStackTrace();
				 				System.out.println(e.getMessage());
				 				
				 			}
					
							break;
			
			case "2":
				
				int enqid;
				
				System.out.println("Enter enquiry id: ");
				enqid=sc.nextInt();
				
				
				try {
					enq=service.getEnquiryList(enqid);
					//ArrayList<Employee> list= service.getEmployeeList(scheme);
					
					if(enq == null)
					{
						System.out.println("No visitor with this id ");
					}
					else
					{
						System.out.println(enq);
					}
				} catch (EnquiryException e) {
					System.out.println(e.getMessage());
					e.printStackTrace();
				}
				
				break;
				
			case "3":
				System.exit(0);
				break;
				
				
			default:
				System.out.println("Invalid choice entered");
			
			}
		}while(true);	

}
}

