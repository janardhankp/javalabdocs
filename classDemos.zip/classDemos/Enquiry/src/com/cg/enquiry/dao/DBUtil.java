package com.cg.enquiry.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.enquiry.exception.EnquiryException;

public class DBUtil {
	
public static Connection getConnection() throws EnquiryException {
		
		Connection conn=null;
		
	try {
		InputStream is=new FileInputStream("src//resources//jdbc.properties");	
			Properties prop=new Properties();
			prop.load(is);
			
			//String driver=prop.getProperty("driver");
			String url=prop.getProperty("url");
			String user=prop.getProperty("username");
			String pwd=prop.getProperty("password");
		
		//	Class.forName(driver);
			conn=DriverManager.getConnection(url ,user ,pwd);
			
			
			
			
	} catch (FileNotFoundException e) {
		
		throw new EnquiryException(e.getMessage());
		
	} catch (IOException e) {
		
		throw new EnquiryException(e.getMessage());
		
	} catch (SQLException e) {
		e.printStackTrace();
		throw new EnquiryException(e.getMessage());
	}
		
		
		return conn;
		
	}


}
