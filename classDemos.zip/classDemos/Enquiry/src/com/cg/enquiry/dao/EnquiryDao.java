package com.cg.enquiry.dao;

import java.util.ArrayList;




import com.cg.enquiry.exception.EnquiryException;
import com.cg.enquiry.dto.Enquiry;

public interface EnquiryDao {
	
	public int insertEnquiryDetails(Enquiry enq) throws EnquiryException;
	public Enquiry getEnquiryDetails(int enqId) throws EnquiryException;

	
	
	
}
