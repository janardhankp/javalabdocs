package com.cg.enquiry.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.enquiry.dto.Enquiry;
import com.cg.enquiry.exception.EnquiryException;


public class EnquiryDaoImpl implements EnquiryDao {
	
	Connection conn;

	@Override
	public int insertEnquiryDetails(Enquiry enq) throws EnquiryException {
		
			conn=DBUtil.getConnection();
			
			String sql="insert into enquiry values"
					+"(enquiryId_seq.nextval,?,?,?,?,?)";
			int enquiryId=0;
			try {
				
				PreparedStatement pstmt=conn.prepareStatement(sql);
				
				pstmt.setInt(1, enq.getEnquiryId());
				pstmt.setString(1, enq.getFirstName());
				pstmt.setString(2, enq.getLastName());
				pstmt.setLong(3, enq.getContactNum());
				pstmt.setString(4, enq.getDomain());
				pstmt.setString(5, enq.getCity());
			
				int r=pstmt.executeUpdate();
				
				if(r==1){
					
					sql="select enquiryId_seq.currval from dual";

					Statement stmt= conn.createStatement();
					ResultSet rs=stmt.executeQuery(sql);
					while(rs.next()){
						enquiryId = rs.getInt(1);
						return enquiryId;
					}
					
				}else
					return 0;
				
			} catch (SQLException e) {
				e.printStackTrace();
				throw new EnquiryException(e.getMessage());
			}
			return 0;	
		}
		
		
	

	@Override
	public Enquiry getEnquiryDetails(int enqId) throws EnquiryException {
		conn=DBUtil.getConnection();
		
		String sql="select enqryId,firstName,lastName,contactNo,domain,city from enquiry where enqryId=?";
		
		
		try {
			
			PreparedStatement pstmt=conn.prepareStatement(sql);
			
			pstmt.setInt(1,enqId);
			ResultSet rs=pstmt.executeQuery();
			
			while(rs.next()){
				
				Enquiry enq=new Enquiry();
				
				enq.setEnquiryId(rs.getInt(1));
				enq.setFirstName(rs.getString(2));
				enq.setLastName(rs.getString(3));
				enq.setContactNum(rs.getLong(4));
				enq.setDomain(rs.getString(5));
				enq.setCity(rs.getString(6));
				return enq;
			}
			
			
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new EnquiryException(e.getMessage());
			
		}
		return null;
	}	
}
