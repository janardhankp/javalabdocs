import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class UpdateDemo {

	public static void main(String[] args) {
		String query="update employee_details " +" set salary=salary+3000"+ "where insuranceScheme='Scheme c'";
		Connection conn;
		Statement stmt;
			try {
				conn=DriverManager.getConnection("jdbc:oracle:thin:@ndaoracle.igatecorp.com:1521:orcl11g","lab011trg19","lab011oracle");
			System.out.println("DB connected");
			stmt= conn.createStatement();
			
			int rows=stmt.executeUpdate(query);
			System.out.println(rows+"updated");
			stmt.close();
			conn.close();
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}


	}

}
