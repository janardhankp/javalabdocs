import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class DeleteDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String query="delete from employee_details"+" where employee_id=1212";
		Connection conn;
		Statement stmt;
			try {
				conn=DriverManager.getConnection("jdbc:oracle:thin:@ndaoracle.igatecorp.com:1521:orcl11g","lab011trg19","lab011oracle");
			System.out.println("DB connected");
			stmt= conn.createStatement();
			
			int rows=stmt.executeUpdate(query);
			System.out.println(rows+"deleted");
			stmt.close();
			conn.close();
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}

	}

}
