import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class InsertDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String query="insert into employee_details values"+ "(846,'suchi',20000,'programmer','Scheme b')";
			Connection conn;
			Statement stmt;
				try {
					conn=DriverManager.getConnection("jdbc:oracle:thin:@ndaoracle.igatecorp.com:1521:orcl11g","lab011trg17","lab011oracle");
				System.out.println("DB connected");
				stmt= conn.createStatement();
				
				int rows=stmt.executeUpdate(query);
				System.out.println(rows+"inserted");
				stmt.close();
				conn.close();
				
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}

	}

}
