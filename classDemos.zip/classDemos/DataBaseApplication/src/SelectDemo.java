import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class SelectDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection conn;
		Statement stmt;
		ResultSet rs;
		try {
			conn=DriverManager.getConnection("jdbc:oracle:thin:@ndaoracle.igatecorp.com:1521:orcl11g","lab011trg19","lab011oracle");
		System.out.println("DB connected");
		stmt= conn.createStatement();
		rs=stmt.executeQuery("select book_code,book_name,book_pub_year from book_masters");
		System.out.println("select query executed");
		
		while(rs.next()){
			System.out.print(rs.getInt(1)+"	");
			System.out.print(rs.getString(2)+"	");
			System.out.println(rs.getInt("book_pub_year"));
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		

	}

}
