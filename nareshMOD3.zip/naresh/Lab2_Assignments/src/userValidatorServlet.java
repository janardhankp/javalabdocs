

import java.io.IOException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class userValidatorServlet
 */
@WebServlet("/userValidatorServlet")
public class userValidatorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       ServletConfig scg;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public userValidatorServlet() {
        super();
        System.out.println("userValidatorServlet constructor is called");
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		super.init(config);
		scg=config;
		System.out.println("init in userValidatorServlet called");
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		String usr=request.getParameter("usr");
		String pwd=request.getParameter("pwd");
		if(usr.equalsIgnoreCase("usr") && pwd.equalsIgnoreCase("pwd")){
		response.sendRedirect("success.html");
		}
		response.sendRedirect("failure.html");
		
	}

}
