package com.cg.ig.dao;

import java.util.ArrayList;

import com.cg.ig.dto.Employee;
import com.cg.ig.exception.EmployeeException;

public interface EmployeeDao {
	public int addEmployeeDetails(Employee emp) throws EmployeeException;
	public boolean validatePassword(String pwd)throws EmployeeException;
	public ArrayList<Employee> allEmployeeDetails() throws EmployeeException;
}
