package com.cg.ig.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.ig.dto.Employee;
import com.cg.ig.exception.EmployeeException;
import com.cg.ig.services.EmployeeService;
import com.cg.ig.services.EmployeeServiceImpl;

/**
 * Servlet implementation class getDataServlet
 */
@WebServlet("/getDataServlet")
public class getDataServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       ServletConfig cg;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public getDataServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    @Override
    public void init(ServletConfig config) throws ServletException {
    	// TODO Auto-generated method stub
    	super.init(config);
    	cg=config;
    }
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter pw=response.getWriter();
		EmployeeService empservice=new EmployeeServiceImpl();
		ServletContext ctx=cg.getServletContext();
		RequestDispatcher rd=ctx.getRequestDispatcher("/DisplayEmployeeDetalsServlet");
		
		try {
			ArrayList<Employee> list=empservice.allEmployeeDetails();
			
			if(list.size()!=0)
			{	
				request.setAttribute("list", list);
				rd.forward(request, response);
//				int i=0;
//				for (Employee employee : list) {
//					pw.println(++i+"--"+employee+"<br/>");
//				}
			}else{
				pw.print("No details found");
			}
		} catch (EmployeeException e) {
			pw.println(e);
		}
		
	}

}
