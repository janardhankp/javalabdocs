package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dto.UserDto;
import com.cg.service.IUserService;
import com.cg.service.UserServicesImpl;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;



	public LoginServlet() {
		super();
		System.out.println("Constructor Called");
	}


	public void init(ServletConfig config) throws ServletException {

		System.out.println("init  Called");
		

	}


	public void destroy() {
		// TODO Auto-generated method stub
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		IUserService userService = new UserServicesImpl();
		UserDto dto=new UserDto();
		PrintWriter pw=response.getWriter();
		String usr=request.getParameter("username");
		String pwd=request.getParameter("password");
		request.setAttribute("UNobj", usr);
		
		//String str=userService.getUserPwd(usr);
		//pw.println(str);
		int rowcount=userService.getUserCount(usr);
		//pw.println(rowcount);
		if(rowcount!=0)
		{	
			dto.setUserId(usr);
			dto.setPwd(pwd);
	
			
			if(userService.ValidateUser(dto))
			{
				//pw.println("Login Success");
				RequestDispatcher rdsuccess=request.getRequestDispatcher("/SuccessServlet");
				rdsuccess.forward(request, response);
			}else{
				//pw.println("Invalid Password");
				RequestDispatcher refailure=request.getRequestDispatcher("html/failure.html");
				refailure.forward(request, response);
			}
		}else{
			RequestDispatcher rdReg=request.getRequestDispatcher("html/Register.html");
			rdReg.forward(request, response);
			
		}
		
	}

}
