package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SuccessServlet
 */
@WebServlet(
		name="SuccessRegistration",
		urlPatterns={"/SuccessServlet"},
		initParams={@WebInitParam(name="compMail",value="hr@capgemini.com")}
		)
public class SuccessServlet extends HttpServlet {
	ServletConfig cg;
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SuccessServlet() {
        super();
        System.out.println("Success Servlet is called");
        // TODO Auto-generated constructor stub
    }
    
		@Override
		public void init(ServletConfig config) throws ServletException {
			// TODO Auto-generated method stub
			super.init(config);
			cg=config;
		}
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter pw=response.getWriter();
	ServletContext ctx=cg.getServletContext();
	String mailid=ctx.getInitParameter("location");
	RequestDispatcher rdheader=ctx.getRequestDispatcher("/html/header.html");
	RequestDispatcher rdfooter=ctx.getRequestDispatcher("/html/footer.html");
	rdheader.include(request, response);
		pw.println("Success<br/>");
		pw.println(mailid);
		pw.print(ctx.getInitParameter("location2")+"<br/>");
		pw.print(cg.getInitParameter("compMail")+"<br>");
		pw.println(request.getAttribute("UNobj"));
		pw.println("<a href='RedirectDemoServlet'> RedirectDemoServlet</a>");
		rdfooter.include(request, response);
	}

}
