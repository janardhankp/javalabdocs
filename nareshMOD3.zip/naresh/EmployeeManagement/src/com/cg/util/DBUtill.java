package com.cg.util;

import java.sql.Connection;




import javax.naming.InitialContext;
import javax.sql.DataSource;


public class DBUtill {
	
	public static Connection getConnection() {
		Connection conn = null;
		try {
			//Class.forName("oracle.jdbc.driver.OracleDriver");
			//conn=DriverManager.getConnection("jdbc:oracle:thin:@ndaoracle.igatecorp.com:1521:orcl11g", "lab011trg15", "lab011oracle");
			InitialContext myContext=new InitialContext();
			DataSource dataSource=(DataSource) myContext.lookup("java:/jdbc/nareshDS");
			conn=dataSource.getConnection();
			
		} catch (Exception e) {
			System.out.println(e);
			
		} 
		
		return conn;
	}
}

