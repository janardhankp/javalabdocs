package com.cg.dto;

public class UserDto {
	 public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	private String userId;
	 private String pwd;
	@Override
	public String toString() {
		return "UserDto [userId=" + userId + ", pwd=" + pwd + "]";
	}
	 
}
