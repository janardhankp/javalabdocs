package com.cg.dto;

import java.sql.Date;
import java.time.LocalDate;

public class Employee {
	private String ename;
	private long esal;
	private int eid;
	private LocalDate doj;
	public LocalDate getDoj() {
		return doj;
	}
	public void setDoj(LocalDate ldt) {
		this.doj = ldt;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public long getEsal() {
		return esal;
	}
	public void setEsal(long esal) {
		this.esal = esal;
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	@Override
	public String toString() {
		return "Employee [ename=" + ename + ", esal=" + esal + ", eid=" + eid
				+ "]";
	}
	
	
}
