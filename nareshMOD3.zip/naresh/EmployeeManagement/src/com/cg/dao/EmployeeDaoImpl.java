package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.dto.Employee;
import com.cg.exception.EmployeeException;
import com.cg.util.DBUtill;

public class EmployeeDaoImpl implements EmployeeDao{
	
	@Override
	public int insertEmp(Employee emp) throws EmployeeException {
		Connection conn=DBUtill.getConnection();
		Statement st=null;
		PreparedStatement pstmt = null;
		String sql="insert into emp656 values(emp_seq.nextval,?,?,?)";
		int DataInserted=0;
		try {
			pstmt=conn.prepareStatement(sql);			
			pstmt.setString(1, emp.getEname());
			pstmt.setLong(2, emp.getEsal());
			pstmt.setString(3, emp.getDoj().getDayOfMonth()+"-"+emp.getDoj().getMonth()+"-"+emp.getDoj().getYear());
			DataInserted=pstmt.executeUpdate();
			if(DataInserted>0)
				DataInserted=getNextEmpId();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			throw new EmployeeException(e.getMessage());
		}finally{
			try {
				conn.close();
				pstmt.close();
			} catch (SQLException e) {
				throw new EmployeeException(e.getMessage());
			}			
		}
		return DataInserted;
	}

	@Override
	public int getNextEmpId() throws EmployeeException{
		int nextId=0;
		Connection conn=DBUtill.getConnection();
		Statement st=null;
		try {
			st=conn.createStatement();
			ResultSet rs=st.executeQuery("select emp_seq.nextval from dual");
			rs.next();
			nextId = rs.getInt(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
			throw new EmployeeException(e.getMessage());
		}				
		return nextId;
	}

	@Override
	public ArrayList<Employee> getAllEmployee() throws EmployeeException {
		
		Connection conn=DBUtill.getConnection();
		Statement st=null;
		ArrayList<Employee> list=new ArrayList<Employee>();
		try {
			
			st=conn.createStatement();
			ResultSet rs=st.executeQuery("select * from emp656");
			while(rs.next()){
				Employee emp=new Employee();
				
				emp.setEid(rs.getInt("eid"));
				emp.setEname(rs.getString("enm"));
				emp.setEsal(rs.getLong("esal"));
				emp.setDoj(rs.getDate("doj").toLocalDate());
				
				
					list.add(emp);

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
			throw new EmployeeException(e.getMessage());
		}				
	
		return list;
		
	}

	@Override
	public Employee getEmployee(int id) throws EmployeeException {
		Connection conn=DBUtill.getConnection();
		PreparedStatement pstmt;
		Employee emp=new Employee();
		try {			
			pstmt=conn.prepareStatement("select * from emp656 where eid=?");
			pstmt.setInt(1, id);
			ResultSet rs=pstmt.executeQuery();
			rs.next();								
				emp.setEid(rs.getInt("eid"));
				emp.setEname(rs.getString("enm"));
				emp.setEsal(rs.getLong("esal"));	
				emp.setDoj(rs.getDate("doj").toLocalDate());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
			throw new EmployeeException(e.getMessage());
		}					
		return emp;
	}

	@Override
	public int UpdateEmp(Employee emp) throws EmployeeException {
		Connection conn=DBUtill.getConnection();
		Statement st=null;
		PreparedStatement pstmt = null;
		String sql="update emp656 set enm=?,esal=? where eid=?";
		int Updated=0;
		try {
			pstmt=conn.prepareStatement(sql);			
			pstmt.setString(1, emp.getEname());
			pstmt.setLong(2, emp.getEsal());
			pstmt.setInt(3, emp.getEid());
			Updated=pstmt.executeUpdate();
			if(Updated>0)
				Updated=getNextEmpId();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			throw new EmployeeException(e.getMessage());
		}finally{
			try {
				conn.close();
				pstmt.close();
			} catch (SQLException e) {
				throw new EmployeeException(e.getMessage());
			}			
		}
		return Updated;
	}

	@Override
	public int deleteEmployee(int id) throws EmployeeException {
		Connection conn=DBUtill.getConnection();
		PreparedStatement pstmt;
		
		int count=0;
		try {			
			pstmt=conn.prepareStatement("delete from emp656 where eid=?");
			pstmt.setInt(1, id);
			count=pstmt.executeUpdate();
																											
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
			throw new EmployeeException(e.getMessage());
		}					
		return count;
		
	}

}
