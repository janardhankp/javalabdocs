package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.dto.UserDto;
import com.cg.util.DBUtill;

public class UserDaoImpl implements IUserDao{
	
	
	@Override
	public int getUserCount(String uid) {
		Connection conn=DBUtill.getConnection();
		PreparedStatement pst = null;
		ResultSet rst = null;
		String sql="select count(*) from userTable where userid = ?";
		int flag = 0;
		try {
			pst=conn.prepareStatement(sql);
			pst.setString(1, uid);
			rst=pst.executeQuery();
			while(rst.next()){
				int a;
				a=rst.getInt(1);
				if(a!=0)
					flag=1;
				else 
					flag=0;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				rst.close();
				pst.close();
				conn.close();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
			
		}
		return flag;
		
	
	}

	@Override
	public boolean ValidateUser(UserDto user) {
		String sql="select * from userTable where userid=?";
		boolean flag = false;
		Connection conn=DBUtill.getConnection();
		PreparedStatement pst = null;
		ResultSet rst = null;
		try {
	
			
			pst=conn.prepareStatement(sql);
			pst.setString(1, user.getUserId());		

			rst=pst.executeQuery();
		
			rst.next();
			String un=rst.getString("userid");
			String pw=rst.getString("password");
			System.out.println(un + "  "+pw );
			if(pw.equalsIgnoreCase(user.getPwd()) 
					&& 
				un.equalsIgnoreCase(user.getUserId())
			)
				flag= true;
			else 
				flag= false;
	
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		finally{
			try {
				rst.close();
				pst.close();
				conn.close();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
			
		}
		return flag;
		
	}

	@Override
	public String getUserPwd(String uid) {
		String sql="select * from userTable where userid = ?";
		String flag = null;
		Connection conn=DBUtill.getConnection();
		PreparedStatement pst = null;
		ResultSet rst = null;
		try {
		
			pst=conn.prepareStatement(sql);
			pst.setString(1, uid);
			rst=pst.executeQuery();
			while(rst.next()){
			flag=rst.getString("password");
			}
			System.out.println(flag);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				rst.close();
				pst.close();
				conn.close();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
			
		}
		return flag;
		
	
	}

}
