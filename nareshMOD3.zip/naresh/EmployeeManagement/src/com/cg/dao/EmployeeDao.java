package com.cg.dao;

import java.util.ArrayList;

import com.cg.dto.Employee;
import com.cg.exception.EmployeeException;

public interface EmployeeDao {
	public int insertEmp(Employee emp)throws EmployeeException;
	public int UpdateEmp(Employee emp)throws EmployeeException;
	public int getNextEmpId()throws EmployeeException;
	public ArrayList<Employee> getAllEmployee()throws EmployeeException;
	public Employee getEmployee(int id)throws EmployeeException;
	public int deleteEmployee(int id)throws EmployeeException;
}
