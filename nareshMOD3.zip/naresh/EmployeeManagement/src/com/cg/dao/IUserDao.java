package com.cg.dao;

import com.cg.dto.UserDto;

public interface IUserDao {
public int getUserCount(String uid);
public boolean ValidateUser(UserDto user);
public String getUserPwd(String uid);
}
