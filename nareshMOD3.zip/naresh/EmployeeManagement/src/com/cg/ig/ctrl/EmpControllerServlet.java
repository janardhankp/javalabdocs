package com.cg.ig.ctrl;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.persistence.criteria.CriteriaBuilder.In;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.Employee;
import com.cg.dto.UserDto;
import com.cg.service.EmployeeService;
import com.cg.service.EmployeeServiceImpl;
import com.cg.service.IUserService;
import com.cg.service.UserServicesImpl;


@WebServlet("/EmpControllerServlet")
public class EmpControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	IUserService service=new UserServicesImpl();
	EmployeeService empservice=new EmployeeServiceImpl();

	ServletConfig cfg;
	public EmpControllerServlet() {
		super();
		System.out.println("empcontrollerservlet constructor");
	}


	public void init(ServletConfig config) throws ServletException 
	{
		super.init(config);
		cfg=config;
		System.out.println("Init fun in empctrlservlet");
	}

	public void destroy() {
		System.out.println("destroyed");

	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);

	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=request.getParameter("action");
		PrintWriter out=response.getWriter();
		if(action.isEmpty()){
			out.println("<b>No Action Defined</b>");
		}else{			
			if(action.equals("DisplayLoginPage"))
			{	
				//This Action is to display Login Page
				RequestDispatcher rd=request.getRequestDispatcher("/jspPages/Login.jsp");
				rd.forward(request, response);	

				//response.sendRedirect("jspPages/Login.jsp");
			}
			if(action.equals("validateLogin")){

				String uid=request.getParameter("usr");
				String pwd=request.getParameter("pwd");
				UserDto ud=new UserDto();
				ud.setUserId(uid);
				ud.setPwd(pwd);
				if(service.getUserCount(uid)!=0){
					if(service.ValidateUser(ud)){
						HttpSession session=request.getSession(true);
						session.setAttribute("UNobj", ud.getUserId());
						RequestDispatcher rdValid=request.getRequestDispatcher("/jspPages/EmployeeOperation.jsp");
						rdValid.forward(request, response);
					}else{
						//This Action is to display Login Page
						RequestDispatcher rd=request.getRequestDispatcher("/jspPages/Login.jsp");
						rd.forward(request, response);	
					}
				}else{
					RequestDispatcher rd=request.getRequestDispatcher("/jspPages/EmpRegister.jsp");
					rd.forward(request, response);
				}

			}
			if(action.equals("DisplayAddEmpPage")){

				RequestDispatcher rd=request.getRequestDispatcher("/jspPages/AddEmp.jsp");
				rd.forward(request, response);
			}
			
			if(action.equals("DisplayDelete")){
				int id=Integer.parseInt(request.getParameter("empid"));
				//successDelete
				int id1=empservice.deleteEmployee(id);
				if(id1!=0){					
					RequestDispatcher rd=request.getRequestDispatcher("/jspPages/ListAllEmployee.jsp");
					request.setAttribute("successDelete", id);
					request.setAttribute("list", empservice.getAllEmployee());
					rd.forward(request, response);
				}
				RequestDispatcher rd=request.getRequestDispatcher("/jspPages/AddEmp.jsp");
				rd.forward(request, response);
			}
			if(action.equals("UpdateEmp")){
				String enm=request.getParameter("txtEmpName");
				long esal=Long.parseLong(request.getParameter("txtEmpSal"));
				int id=Integer.parseInt(request.getParameter("txtEmpId"));
				//LocalDate doj=request.getParameter("txtEmpDoj");
				Employee emp=new Employee();
				//emp.setDoj(doj);
				emp.setEname(enm);
				emp.setEsal(esal);
				emp.setEid(id);
				int id1=empservice.UpdateEmp(emp);
				if(id1!=0){					
					RequestDispatcher rd=request.getRequestDispatcher("/jspPages/ListAllEmployee.jsp");
					request.setAttribute("successUpdate", enm);
					request.setAttribute("list", empservice.getAllEmployee());
					rd.forward(request, response);
				}
				
				//RequestDispatcher rd=request.getRequestDispatcher("/jspPages/AddEmp.jsp");
				//rd.forward(request, response);
			}
			if(action.equals("all")){
						
					RequestDispatcher rd=request.getRequestDispatcher("/jspPages/ListAllEmployee.jsp");
					
					request.setAttribute("list", empservice.getAllEmployee());
					rd.forward(request, response);
				
			}
			if(action.equals("SearchResult"))
			{		
				int id=Integer.parseInt(request.getParameter("txtId"));
				Employee emp=new Employee();
				emp=empservice.getEmployee(id);
				RequestDispatcher rd=request.getRequestDispatcher("/jspPages/SearchResult.jsp");
				request.setAttribute("Data", emp);
				rd.forward(request, response);			
			}
			if(action.equals("search")){
				
				RequestDispatcher rd=request.getRequestDispatcher("/jspPages/Search.jsp");
				
				
				rd.forward(request, response);
			
			}
			if(action.equals("DisplayEdit")){

				RequestDispatcher rd=request.getRequestDispatcher("/jspPages/Editemp.jsp");
				int id=Integer.parseInt(request.getParameter("empid"));
				request.setAttribute("data", empservice.getEmployee(id));
				rd.forward(request, response);
			}
			if(action.equals("DisplayAdd")){

				RequestDispatcher rd=request.getRequestDispatcher("/jspPages/Deleteemp.jsp");
				rd.forward(request, response);
			}
			if(action.equals("InsertEmp")){

				String enm=request.getParameter("txtEmpName");
				long esal=Long.parseLong(request.getParameter("txtEmpSal"));
				String date=request.getParameter("txtEmpDoj");
				DateTimeFormatter dtf=DateTimeFormatter.ofPattern("yyyy-MM-dd");
				LocalDate ldt=LocalDate.parse(date, dtf);
				
				System.out.println(ldt);
				//LocalDate doj=request.getParameter("txtEmpDoj");
				Employee emp=new Employee();
				//emp.setDoj(doj);
				emp.setEname(enm);
				emp.setEsal(esal);
				emp.setDoj(ldt);
				int id=empservice.insertEmp(emp);
				if(id!=0){					
					RequestDispatcher rd=request.getRequestDispatcher("/jspPages/ListAllEmployee.jsp");
					request.setAttribute("list", empservice.getAllEmployee());
					rd.forward(request, response);
				}

			}
		}
	}
}
