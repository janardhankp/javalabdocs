package com.cg.exception;

public class EmployeeException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String errorMsg;
	public EmployeeException(String errorMsg){
		super(errorMsg);
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return errorMsg;
	}
}
