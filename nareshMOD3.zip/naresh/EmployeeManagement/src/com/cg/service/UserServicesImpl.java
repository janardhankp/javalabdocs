package com.cg.service;

import com.cg.dao.IUserDao;
import com.cg.dao.UserDaoImpl;
import com.cg.dto.UserDto;

public class UserServicesImpl implements IUserService{
IUserDao dao=new UserDaoImpl();
	@Override
	public int getUserCount(String uid) {
		// TODO Auto-generated method stub
		return dao.getUserCount(uid);
	}

	@Override
	public boolean ValidateUser(UserDto user) {
		// TODO Auto-generated method stub
		return dao.ValidateUser(user);
	}

	@Override
	public String getUserPwd(String uid) {
		// TODO Auto-generated method stub
		return dao.getUserPwd(uid);
	}

}
