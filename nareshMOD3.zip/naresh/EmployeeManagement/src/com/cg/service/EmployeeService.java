package com.cg.service;

import com.cg.dao.EmployeeDao;

public interface EmployeeService extends EmployeeDao{

}
