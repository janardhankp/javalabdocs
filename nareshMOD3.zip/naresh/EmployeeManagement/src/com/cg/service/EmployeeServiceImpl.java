package com.cg.service;

import java.util.ArrayList;

import com.cg.dao.EmployeeDao;
import com.cg.dao.EmployeeDaoImpl;
import com.cg.dto.Employee;
import com.cg.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService{
	EmployeeDao edao=new EmployeeDaoImpl();
	@Override
	public int insertEmp(Employee emp) throws EmployeeException {
		// TODO Auto-generated method stub
		return edao.insertEmp(emp);
	}
	@Override
	public int getNextEmpId() throws EmployeeException {
		// TODO Auto-generated method stub
		return edao.getNextEmpId();
	}
	@Override
	public ArrayList<Employee> getAllEmployee() throws EmployeeException {
		// TODO Auto-generated method stub
		return edao.getAllEmployee();
	}
	@Override
	public Employee getEmployee(int id) throws EmployeeException {
		// TODO Auto-generated method stub
		return edao.getEmployee(id);
	}
	@Override
	public int UpdateEmp(Employee emp) throws EmployeeException {
		// TODO Auto-generated method stub
		return edao.UpdateEmp(emp);
	}
	@Override
	public int deleteEmployee(int id) throws EmployeeException {
		// TODO Auto-generated method stub
		return edao.deleteEmployee(id);
	}
	
}
