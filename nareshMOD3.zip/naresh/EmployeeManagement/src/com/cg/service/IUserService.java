package com.cg.service;

import com.cg.dao.IUserDao;

public interface IUserService extends IUserDao{

}
