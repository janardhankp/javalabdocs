package com.cg.ig.services;

import com.cg.ig.dao.EmployeeDao;

public interface EmployeeService extends EmployeeDao{

}
