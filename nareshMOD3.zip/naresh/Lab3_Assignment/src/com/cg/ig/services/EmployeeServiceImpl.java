package com.cg.ig.services;

import com.cg.ig.dao.EmployeeDao;
import com.cg.ig.dao.EmployeeDaoImpl;
import com.cg.ig.dto.Employee;
import com.cg.ig.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService{
	EmployeeDao edao=new EmployeeDaoImpl();
	@Override
	public int addEmployeeDetails(Employee emp) throws EmployeeException {
		// TODO Auto-generated method stub
		return edao.addEmployeeDetails(emp);
	}

	@Override
	public boolean validatePassword(String pwd) throws EmployeeException {
		// TODO Auto-generated method stub
		return edao.validatePassword(pwd);
	}

	
}
