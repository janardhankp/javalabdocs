package com.cg.ig.exception;

public class EmployeeException extends Exception{

	String errorMsg;
	public EmployeeException(String msg) {
		errorMsg=msg;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return errorMsg;
	}

}
