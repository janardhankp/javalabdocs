package com.cg.ig.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.ig.dto.Employee;
import com.cg.ig.exception.EmployeeException;
import com.cg.ig.services.EmployeeService;
import com.cg.ig.services.EmployeeServiceImpl;

/**
 * Servlet implementation class loginServlet
 */
@WebServlet("/loginServlet")
public class loginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public loginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter pw=response.getWriter();
		EmployeeService empservice=new EmployeeServiceImpl();
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		String pwd=request.getParameter("pwd");
		String gender=request.getParameter("gender");
		String skills[]=request.getParameterValues("skill[]");
		String skillAll=Arrays.toString(skills);
		String city=request.getParameter("city");
		int length=skillAll.length();
		
		skillAll=skillAll.replace(skillAll.charAt(0), ' ');
		skillAll=skillAll.replace(skillAll.charAt(length-1), ' ');
		skillAll=skillAll.trim();
		
		Employee emp=new Employee();
		emp.setFirstname(fname);
		emp.setLastname(lname);
		emp.setGender(gender.charAt(0));
		emp.setPassword(pwd);
		emp.setSkillset(skillAll);
		emp.setCity(city);
		
		try {
			boolean test=empservice.validatePassword(pwd);
			if(test){
			int count=empservice.addEmployeeDetails(emp);
			
			if(count==1)
				response.sendRedirect("html/success.html");
			else 
				response.sendRedirect("html/failure.html");
			}else
				{
				pw.println("Enter onther passowrd");
				RequestDispatcher rd=request.getRequestDispatcher("index.html");
				rd.include(request, response);
				}
		} catch (EmployeeException e) {
			pw.println(e);
			
		}
	}

}
