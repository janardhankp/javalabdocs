package com.cg.ig.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.ig.dto.Employee;
import com.cg.ig.exception.EmployeeException;

public class EmployeeDaoImpl implements EmployeeDao{

	@Override
	public int addEmployeeDetails(Employee emp) throws EmployeeException {
		try {
			Connection conn=DBUtill.getConnection();
			String sql="insert into RegisteredUsers values(?,?,?,?,?,?)";
			
			PreparedStatement pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, emp.getFirstname());
			pstmt.setString(2, emp.getLastname());
			pstmt.setString(3,String.valueOf(emp.getGender()));
			pstmt.setString(4, emp.getPassword());
			pstmt.setString(5, emp.getSkillset());
			pstmt.setString(6, emp.getCity());
			int count=pstmt.executeUpdate();
			if(count==1)
				return count;
			else return 0;
		} catch (SQLException e) {
			throw new EmployeeException(e.getMessage());
		}
		
		
	}

	@Override
	public boolean validatePassword(String pwd) throws EmployeeException {
		String sql="select count(*) from RegisteredUsers where password = ?";
		boolean flag = false;
		Connection conn=DBUtill.getConnection();
		PreparedStatement pst = null;
		ResultSet rst = null;
		try {
		
			pst=conn.prepareStatement(sql);
			pst.setString(1, pwd);
			rst=pst.executeQuery();
			rst.next();
			if(rst.getInt(1) > 0)
				flag=false;
			else flag=true;
			
			System.out.println(flag);
		} catch (SQLException e) {
			throw new EmployeeException(e.getMessage());
		}
		finally{
			try {
				rst.close();
				pst.close();
				conn.close();
				
			} catch (SQLException e) {
				throw new EmployeeException(e.getMessage());
			}
			
		}
		return flag;
		
	}

	

}
